<?php
$servername = "localhost";
$username = "wesettle_form_use";
$password = "xdfx36W#^#$@";
$dbname = "wesettle_form";

// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "infuzex-wesettle";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

?>